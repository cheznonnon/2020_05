// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




MSG
n_catpad_msgloop( HWND hwnd )
{

	UINT msg_mousewheel = RegisterWindowMessage( n_posix_literal( "MSWHEEL_ROLLMSG" ) );	
//if ( msg_mousewheel == WM_NULL ) { n_posix_debug_literal( " WM_NULL " ); }


	MSG msg; ZeroMemory( &msg, sizeof( MSG ) );
	while( 1 <= GetMessage( &msg, NULL, 0, 0 ) )
	{

		if ( msg.hwnd == hwnd )
		{

			if ( msg.message == WM_LBUTTONDOWN )
			{
				n_win_simplemenu_close( n_win_simplemenu_target );
			}

		} else {

			if ( msg.message == WM_DROPFILES )
			{

				// [!] : for Windows95 without IE4

				msg.hwnd = hwnd;

			} else
			if (
				( msg.message >= WM_KEYFIRST )
				&&
				( msg.message <= WM_KEYLAST  )
			)
			{

				// [!] : keyboard input event redirector

				n_win_message_send( hwnd, msg.message, msg.wParam, msg.lParam );

			} else
			if ( msg.message == WM_LBUTTONDOWN )
			{
				n_win_simplemenu_close( n_win_simplemenu_target );
			}

		}


		n_win_mousewheel_redirector( msg_mousewheel, &msg );


		n_win_mbutton2centering_proc( msg.hwnd, msg.message, msg.wParam, msg.lParam );


		TranslateMessage( &msg );
		DispatchMessage ( &msg );

	}


	return msg;
}

WPARAM
n_catpad_main( const n_posix_char *mutex, void *wndproc )
{

	HANDLE hmutex = NULL;

	if ( mutex != NULL )
	{
		hmutex = n_win_mutex_init( hmutex, mutex );
		if ( hmutex == NULL ) { return 0; }
	}


	// [!] : WinXP or later : ghost window feature is buggy
	//
	//	XP    : a parent folder or an EXE file will be locked
	//	Vista : removable drive cannot be unplugged
	//	7     : an old EXE file cache is used and keep on crashing

	n_win_ghostwindow_disable();


	HWND hwnd = NULL; n_win_gui( NULL, N_WIN_GUI_WINDOW, wndproc, &hwnd );


	WPARAM wparam = n_catpad_msgloop( hwnd ).wParam;


	if ( mutex != NULL )
	{
		hmutex = n_win_mutex_exit( hmutex );
	}


#ifdef N_MEMORY_DEBUG

n_posix_debug_literal( "%d", n_memory_refcount );

#endif // #ifdef N_MEMORY_DEBUG


	return wparam;
}


