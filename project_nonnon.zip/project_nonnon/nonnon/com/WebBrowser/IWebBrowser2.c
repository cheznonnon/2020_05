// Nonnon COM : IWebBrowser
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File


// [!] : Functionality of CLSID_WebBrowser with CLSID_InternetExplorer
//
//	[ Internet Properties ]
//
//	changement will be auto-applied
//
//	[ Shell Embedding ]
//
//	this will be a parent window of "Shell DocObject View"
//	"Shell Embedding" accepts MoveWindow()
//
//	[ IWebBrowser2 ]
//
//	behavior is a little different
//	CLSID_WebBrowser has fewer functionality
//
//	[ HTMLDocument2 ]
//
//	IE6 : IHTMLEventObj is not visible in some cases


// [x] : Compatibility : CLSID_InternetExplorer
//
//	[!] : 2015/07/02 : CLSID_InternetExplorer support is removed
//
//	95   + IE3 : NG : CLSID_InternetExplorer is not exist
//	95   + IE4 : OK : HTMLDocumentEvents : DISPID_ONCONTEXTMENU is not available
//	98SE + IE5 : OK : call n_IWebBrowser_embed() each times at BeforeNavigate2()
//	2000 + IE6 : OK : redraw error when a paraent window is top-level window
//	XP   + IE6 : OK :
//	XP   + IE7 : OK : annoying "Information Bar" and "Balloon Tips"
//	XP   + IE8 : OK : IWebBrowser2 only supported
//	7    + IE8 : NG : restricted under Protected Mode
//
//	IE3 : "about:*" is not available
//
//	[ Security Problems ]
//
//	cache files are always used
//	"Internet Properties" settings are not applied until OleUninitialize() is done


// [x] : Compatibility : CLSID_WebBrowser
//
//	95   + IE3 : NG : CLSID_WebBrowser is not exist
//	95   + IE4 : OK : HTMLDocumentEvents : DISPID_ONCONTEXTMENU is not available
//	98SE + IE5 : OK : IHTMLDocument2_get_title() returns empty string
//	2000 + IE6 : OK : Open Dialog and Find Dialog is not available
//	XP   + IE6 : OK :
//	XP   + IE7 : OK :
//	XP   + IE8 : OK :
//	7    + IE8 : OK : not influenced by Protected Mode


// [!] : Event Sink : Windows 7 + IE8
//
//	[ IWebBrowser ]
//
//	3050f260-98b5-11cf-bb82-00aa00bdce0b : HTMLDocumentEvents
//	3050f5a0-98b5-11cf-bb82-00aa00bdce0b : HTMLDocumentEvents3
//	1dc9ca50-06ef-11d2-8415-006008c3fbfc : ITridentEventSink
//	00020400-0000-0000-c000-000000000046 : IID_IDispatch
//
//	IID_IDispatch       : exdispid.h : 100-114 200-283
//
//
//	[ IHTMLDocument2 ]
//
//	9bfbbc02-eff1-101a-84ed-00aa00341d07 : IPropertyNotifySink
//	3050f260-98b5-11cf-bb82-00aa00bdce0b : HTMLDocumentEvents
//	3050f613-98b5-11cf-bb82-00aa00bdce0b : HTMLDocumentEvents2
//	3050f5a0-98b5-11cf-bb82-00aa00bdce0b : HTMLDocumentEvents3
//	1dc9ca50-06ef-11d2-8415-006008c3fbfc : ITridentEventSink
//	00020400-0000-0000-c000-000000000046 : IID_IDispatch
//
//	IPropertyNotifySink : nothing to happen
//	ITridentEventSink   : crash : "stop to working"
//	IID_IDispatch       : the same events are sent with HTMLDocumentEvents2




#ifndef _H_NONNON_WIN32_COM_IWEBBROWSER2
#define _H_NONNON_WIN32_COM_IWEBBROWSER2




#define N_IWEBBROWSER2_TIMEOUT ( 500 )




#define n_IWebBrowser2_back( _this ) IWebBrowser2_GoBack(    _this )
#define n_IWebBrowser2_next( _this ) IWebBrowser2_GoForward( _this )
//#define n_IWebBrowser2_home( _this ) IWebBrowser2_GoHome(    _this )
#define n_IWebBrowser2_load( _this ) IWebBrowser2_Refresh(   _this )
#define n_IWebBrowser2_stop( _this ) IWebBrowser2_Stop(      _this )

void
n_IWebBrowser2_wait( IWebBrowser2 *_this )
{

	if ( _this == NULL ) { return; }


	// [!] : use some timing errors like drawing, resizing or navigating


	while( 1 )
	{

		VARIANT_BOOL b = VARIANT_TRUE;
		IWebBrowser2_get_Busy( _this, &b );

		if ( b == VARIANT_FALSE ) { break; }

		n_posix_sleep( 500 );

	}


	return;
}

IHTMLDocument2*
n_IWebBrowser2_MSHTML( IWebBrowser2 *_this )
{

	if ( _this == NULL ) { return NULL; }


	IDispatch *disp = NULL;
	IWebBrowser2_get_Document( _this, (void*) &disp );

	if ( disp == NULL )
	{

		n_com_debug_a( "IWebBrowser2::get_Document" );

		return NULL;
	}


	IHTMLDocument2 *hd = NULL;
	n_com_interface( disp, n_guid_IID_IHTMLDocument2, (void*) &hd );
	n_com_release( disp );

	if ( hd == NULL )
	{

		n_com_debug_a( "IID_IHTMLDocument2" );

		return NULL;
	}


	return hd;
}

void
n_IWebBrowser2_go( IWebBrowser2 *_this, BSTR url )
{

	if ( _this == NULL ) { return; }


	// [MSDN] : Win2000 + IE6 : these are not supported
	//
	//	navNoHistory
	//	navNoReadFromCache

	// [x] : a new window will be suppressed when using parameters

	// [x] : if you use "(*Cancel) = VARIANT_TRUE;" at BeforeNavigate2
	//
	//	a : this module will hang up when n_IWebBrowser2_wait() is used
	//	b : crashes while busy

//n_com_debug_w( url );


/*
	VARIANT Flags;
	VARIANT TargetFrameName;
	VARIANT PostData;
	VARIANT Headers;


	VariantInit( &Flags           ); V_VT( &Flags           ) = VT_I4;
	VariantInit( &TargetFrameName ); V_VT( &TargetFrameName ) = VT_BSTR;
	VariantInit( &PostData        ); V_VT( &PostData        ) = VT_ARRAY | VT_UI1;
	VariantInit( &Headers         ); V_VT( &Headers         ) = VT_BSTR;

	V_I4  ( &Flags           ) = 0;//navNoHistory | navNoReadFromCache | navNoWriteTocache;
	V_BSTR( &TargetFrameName ) = n_com_bstr_init_literal( "" );//n_com_bstr_init_literal( "_self" );
	V_BSTR( &Headers         ) = n_com_bstr_init_literal( "" );
*/


	//HRESULT hr = IWebBrowser2_Navigate( _this, url, &Flags, &TargetFrameName, &PostData, &Headers );
	HRESULT hr = IWebBrowser2_Navigate( _this, url, NULL, NULL, NULL, NULL );

	if ( FAILED( hr ) )
	{
		n_com_debug_a( "IWebBrowser2::Navigate" );
	}

/*
	n_com_bstr_exit( V_BSTR( &TargetFrameName ) );
	n_com_bstr_exit( V_BSTR( &Headers         ) );
*/

	return;
}

BSTR
n_IWebBrowser2_url( IWebBrowser2 *_this )
{

	if ( _this == NULL ) { return n_com_bstr_init_literal( "" ); }


	// [!] : use n_com_bstr_exit() to free


	BSTR bstr;

	IWebBrowser2_get_LocationURL( _this, &bstr );


	return bstr;
}

BSTR
n_IWebBrowser2_title( IWebBrowser2 *_this )
{

	// [!] : use n_com_bstr_exit() to free


	if ( _this == NULL ) { return n_com_bstr_init_literal( "" ); }


	BSTR bstr = L"";


	// [x] : Win98 : bstr will be empty string


	IHTMLDocument2 *hd2 = n_IWebBrowser2_MSHTML( _this );
	if ( hd2 != NULL )
	{
		IHTMLDocument2_get_title( hd2, &bstr );
	}
	n_com_release( hd2 );


	// [!] : Fallback

	if ( 0 == wcslen( bstr ) ) { IWebBrowser2_get_LocationName( _this, &bstr ); }


	return bstr;
}

BSTR
n_IWebBrowser2_status( IWebBrowser2 *_this )
{

	// [!] : use n_com_bstr_exit() to free


	if ( _this == NULL ) { return n_com_bstr_init_literal( "" ); }


	BSTR bstr;

	HRESULT hret = IWebBrowser2_get_StatusText( _this, &bstr );
	if ( FAILED( hret ) )
	{

		IHTMLDocument2 *hd2 = n_IWebBrowser2_MSHTML( _this );
		if ( hd2 == NULL ) { return n_com_bstr_init_literal( "" ); }

		IHTMLWindow2   *hw2 = NULL;
		IHTMLDocument2_get_parentWindow( hd2, &hw2 );
		if ( hw2 == NULL ) { n_com_release( hd2 ); return n_com_bstr_init_literal( "" ); }


		IHTMLWindow2_get_status( hw2, &bstr );

		n_com_release( hw2 );
		n_com_release( hd2 );

	}


	return bstr;
}

BSTR
n_IWebBrowser2_useragent( IWebBrowser2 *_this )
{

	// [!] : use n_com_bstr_exit() to free


	if ( _this == NULL ) { return n_com_bstr_init_literal( "" ); }


	IHTMLDocument2 *hd2 = n_IWebBrowser2_MSHTML( _this );
	if ( hd2 == NULL ) { return n_com_bstr_init_literal( "" ); }

	IHTMLWindow2   *hw2 = NULL;
	IHTMLDocument2_get_parentWindow( hd2, &hw2 );
	if ( hw2 == NULL ) { n_com_release( hd2 ); return n_com_bstr_init_literal( "" ); }


	BSTR bstr;

	IOmNavigator *omn = NULL;
	IHTMLWindow2_get_navigator( hw2, &omn );

	if ( omn == NULL )
	{
		bstr = n_com_bstr_init_literal( "" );
	} else {
		omn->lpVtbl->get_userAgent( omn, &bstr );
	}

	n_com_release( omn );


	n_com_release( hw2 );
	n_com_release( hd2 );


	return bstr;
}

#define n_IWebBrowser2_version() n_sysinfo_version_ie( NULL )

void
n_IWebBrowser2_focus( IWebBrowser2 *_this )
{

	// [Mechanism]
	//
	//	IE4/5/6      : SetFocus() to HWND of "IEFrame" available
	//	IE7 or later : automatically maintained by IWebBrowser2
	//
	//	[x] : but focus will be lost sometimes
	//
	//	[MSDN] : SetForegroundWindow() is handeled as special


	IHTMLDocument2 *hd2 = n_IWebBrowser2_MSHTML( _this );
	IHTMLWindow2   *hw2 = NULL;

	if ( hd2 != NULL )
	{
		IHTMLDocument2_get_parentWindow( hd2, &hw2 );
	}

	if ( hw2 != NULL )
	{
		IHTMLWindow2_focus( hw2 );
	}

	n_com_release( hw2 );
	n_com_release( hd2 );


	return;
}

void
n_IWebBrowser2_resize( IWebBrowser2 *_this, int csx, int csy )
{

	// [Mechanism]
	//
	//	heavier than MoveWindow()
	//	MoveWindow() is always needed after calling this
	//
	//	[ Buggy ]
	//	call this before GoHome()


	// [!] : you can also use these methods but behavior is strange
	//
	//	IHTMLWindow2_resizeTo()
	//	IOleInPlaceObject_SetObjectRects()


	if ( _this == NULL ) { return; }


	// [Patch]

	IWebBrowser2_ClientToWindow( _this, &csx, &csy );

	csx -= GetSystemMetrics( SM_CXSIZEFRAME );
	csy -= GetSystemMetrics( SM_CYSIZEFRAME );


	IWebBrowser2_put_Width ( _this, csx );
	IWebBrowser2_put_Height( _this, csy );


	return;
}

void
n_IWebBrowser2_find( IWebBrowser2 *_this )
{

	// [!] : this code is IE7 or later only
	//
	//	n_IWebBrowser2_exec( _this, OLECMDID_FIND )


	IHTMLDocument2 *d2 = n_IWebBrowser2_MSHTML( _this );
	if ( d2 == NULL ) { return; }


	IOleCommandTarget *ct = NULL;
	n_com_interface( d2, n_guid_IID_IOleCommandTarget, (void*) &ct );
	if ( ct == NULL ) { n_com_release( d2 ); return; }
//n_posix_debug_literal( " ! " );


	const GUID guid = n_CGID_WebBrowser;
	IOleCommandTarget_Exec( ct, &guid, HTMLID_FIND, 0, NULL, NULL );


	n_com_release( ct );
	n_com_release( d2 );


	return;
}

void
n_IWebBrowser2_exec( IWebBrowser2 *_this, int olecmdid )
{

	// [x] : OLECMDID_COPY / OLECMDID_PASTE / OLECMDID_CUT
	//
	//	user can edit HTML contents directly


	// [x] : IE6 : OLECMDID_OPEN / OLECMDID_FIND
	//
	//	not work


	if ( olecmdid == OLECMDID_FIND )
	{
		n_IWebBrowser2_find( _this );
	} else {
		IWebBrowser2_ExecWB( _this, olecmdid, OLECMDEXECOPT_DODEFAULT, NULL, NULL );
	}


	return;
}

void
n_IWebBrowser2_zoom_default( IWebBrowser2 *_this )
{
//n_posix_debug_literal( "" );

	if ( _this == NULL ) { return; }


	HRESULT hr;


	VARIANT v; VariantInit( &v );

	V_VT( &v ) = VT_I4;

	HDC hdc = GetDC( NULL );

	int dpi_x = GetDeviceCaps( hdc, LOGPIXELSX );
	//int dpi_y = GetDeviceCaps( hdc, LOGPIXELSY );

	ReleaseDC( NULL, hdc );

	V_I4( &v ) = (LONG) ( ( (double) dpi_x / 96 ) * 100 );

	hr = IWebBrowser2_ExecWB
	(
		_this,
		OLECMDID_OPTICAL_ZOOM,
		OLECMDEXECOPT_DONTPROMPTUSER,
		&v,
		NULL
	);

	if ( false == FAILED( hr ) ) { return; }


	V_I4( &v ) = 2;

	hr = IWebBrowser2_ExecWB
	(
		_this,
		OLECMDID_ZOOM,
		OLECMDEXECOPT_DONTPROMPTUSER,
		&v,
		NULL
	);

	if ( false == FAILED( hr ) ) { return; }

//n_posix_debug_literal( "failed" );


	return;
}

void
n_IWebBrowser2_exit( IWebBrowser2 *_this, DWORD *cookie )
{

	if ( _this == NULL ) { return; }


	// [Needed] : when IWebBrowser2 is made by OleCreate()

	IOleObject *oo = NULL;
	n_com_interface( _this, n_guid_IID_IOleObject, (void*) &oo );

	if ( oo != NULL ) { IOleObject_Close( oo, OLECLOSE_NOSAVE ); }

	n_com_release( oo );


	if ( cookie != NULL )
	{
		n_com_override_exit( _this, n_guid_DIID_DWebBrowserEvents2, cookie );
	}

	n_com_release( _this );


	return;
}


#endif // _H_NONNON_WIN32_COM_IWEBBROWSER2

