// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_ITASKBARLIST
#define _H_NONNON_WIN32_ITASKBARLIST




//#include "../../com/com.c"

#include "../win.c"




#ifdef _MSC_VER

#include <shobjidl_core.h>

#endif // #ifdef _MSC_VER




const GUID n_guid_CLSID_TaskbarList = { 0x56FDF344,0xFD6D,0x11D0,{ 0x95,0x8A, 0x00,0x60,0x97,0xC9,0xA0,0x90 } };
const GUID n_guid_IID_ITaskbarList3 = { 0xea1afb91,0x9e28,0x4b86,{ 0x90,0xe9, 0x9e,0x9f,0x8a,0x5e,0xef,0xaf } };




#ifndef __shobjidl_core_h__


#include <ole2.h>




#define n_str_guid_CLSID_TaskbarList n_posix_literal( "{56FDF344-FD6D-11D0-958A-006097C9A090}" )
#define n_str_guid_IID_ITaskbarList  n_posix_literal( "{56FDF342-FD6D-11d0-958A-006097C9A090}" )
#define n_str_guid_IID_ITaskbarList2 n_posix_literal( "{602D4995-B13A-429b-A66E-1935E44F4317}" )
#define n_str_guid_IID_ITaskbarList3 n_posix_literal( "{ea1afb91-9e28-4b86-90e9-9e9f8a5eefaf}" )




#define HIMAGELIST    HANDLE
#define LPTHUMBBUTTON void*

enum TBPFLAG
{

	TBPF_NOPROGRESS    = 0,
	TBPF_INDETERMINATE = 0x1,
	TBPF_NORMAL        = 0x2,
	TBPF_ERROR         = 0x4,
	TBPF_PAUSED        = 0x8

} TBPFLAG;

EXTERN_C const IID IID_ITaskbarList3;
#define INTERFACE ITaskbarList3
DECLARE_INTERFACE_(ITaskbarList3,IUnknown)
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS ) PURE;
	STDMETHOD_( ULONG, Release )( THIS ) PURE;

	STDMETHOD ( HrInit                )( THIS ) PURE;
	STDMETHOD ( AddTab                )( THIS_ HWND hwnd ) PURE;
	STDMETHOD ( DeleteTab             )( THIS_ HWND hwnd ) PURE;
	STDMETHOD ( ActivateTab           )( THIS_ HWND hwnd ) PURE;
	STDMETHOD ( SetActiveAlt          )( THIS_ HWND hwnd ) PURE;
	STDMETHOD ( MarkFullscreenWindow  )( THIS_ HWND hwnd, BOOL fFullscreen ) PURE;
	STDMETHOD ( SetProgressValue      )( THIS_ HWND hwnd, ULONGLONG ullCompleted, ULONGLONG ullTotal ) PURE;
	STDMETHOD ( SetProgressState      )( THIS_ HWND hwnd, int tbpFlags ) PURE;
	STDMETHOD ( RegisterTab           )( THIS_ HWND hwndTab, HWND hwndMDI ) PURE;
	STDMETHOD ( UnregisterTab         )( THIS_ HWND hwndTab ) PURE;
	STDMETHOD ( SetTabOrder           )( THIS_ HWND hwndTab, HWND hwndInsertBefore ) PURE;
	STDMETHOD ( SetTabActive          )( THIS_ HWND hwndTab, HWND hwndMDI, DWORD dwReserved ) PURE;
	STDMETHOD ( ThumbBarAddButtons    )( THIS_ HWND hwnd, UINT cButtons, LPTHUMBBUTTON pButton ) PURE;
	STDMETHOD ( ThumbBarUpdateButtons )( THIS_ HWND hwnd, UINT cButtons, LPTHUMBBUTTON pButton ) PURE;
	STDMETHOD ( ThumbBarSetImageList  )( THIS_ HWND hwnd, HIMAGELIST himl ) PURE;
	STDMETHOD ( SetOverlayIcon        )( THIS_ HWND hwnd, HICON hIcon, LPCWSTR pszDescription ) PURE;
	STDMETHOD ( SetThumbnailTooltip   )( THIS_ HWND hwnd, LPCWSTR pszTip ) PURE;
	STDMETHOD ( SetThumbnailClip      )( THIS_ HWND hwnd, RECT *prcClip ) PURE;
};
#undef INTERFACE


#define ITaskbarList3_Release(          p        ) (p)->lpVtbl->Release(          p        )
#define ITaskbarList3_SetProgressValue( p, a,b,c ) (p)->lpVtbl->SetProgressValue( p, a,b,c )
#define ITaskbarList3_SetProgressState( p, a,b   ) (p)->lpVtbl->SetProgressState( p, a,b   )


#endif // #ifndef __shobjidl_core_h__



ITaskbarList3*
n_ITaskbarList_init( void )
{

	// [Needed] : call this after ShowWindow()

	OleInitialize( NULL );

	ITaskbarList3 *p = NULL;

	CoCreateInstance( &n_guid_CLSID_TaskbarList, NULL, CLSCTX_ALL, &n_guid_IID_ITaskbarList3, (void*) &p );

	return p;
}

void
n_ITaskbarList_stop( ITaskbarList3 *p, HWND hwnd )
{

	if ( p == NULL ) { return; }

	ITaskbarList3_SetProgressValue( p, hwnd, 0, 0 );

	return;
}

void
n_ITaskbarList_exit( ITaskbarList3 *p, HWND hwnd )
{

	if ( p == NULL ) { return; }

	n_ITaskbarList_stop( p, hwnd );
	ITaskbarList3_Release( p );

	OleUninitialize();

	return;
}

#define N_ITASKBARLIST_MODE_GREEN  ( 0 )
#define N_ITASKBARLIST_MODE_RED    ( 1 )
#define N_ITASKBARLIST_MODE_YELLOW ( 2 )

void
n_ITaskbarList_mode( ITaskbarList3 *p, HWND hwnd, int mode )
{

	if ( p == NULL ) { return; }


	if ( mode == N_ITASKBARLIST_MODE_GREEN  )
	{
		ITaskbarList3_SetProgressState( p, hwnd, TBPF_NORMAL );
	} else
	if ( mode == N_ITASKBARLIST_MODE_RED    )
	{
		ITaskbarList3_SetProgressState( p, hwnd, TBPF_ERROR );
	} else
	if ( mode == N_ITASKBARLIST_MODE_YELLOW )
	{
		ITaskbarList3_SetProgressState( p, hwnd, TBPF_PAUSED );
	}// else


	return;
}

void
n_ITaskbarList_loop( ITaskbarList3 *p, HWND hwnd, ULONGLONG progress, ULONGLONG maximum )
{

	if ( p == NULL ) { return; }

	ITaskbarList3_SetProgressValue( p, hwnd, progress, maximum );

	return;
}


#endif // _H_NONNON_WIN32_ITASKBARLIST



/*
LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const int max_count = 1000;
	const u32 interval  =   10;


	static ITaskbarList3 *p = NULL;

	static int n = 0;


	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "Taskbar Progress", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );


		ShowWindow( hwnd, SW_NORMAL );


		// [Needed] : after ShowWindow()

		//n_com_class( n_str_guid_CLSID_TaskbarList, n_str_guid_IID_ITaskbarList3, (void*) &p );
		CoCreateInstance( &n_guid_CLSID_TaskbarList, NULL, CLSCTX_ALL, &n_guid_IID_ITaskbarList3, (void*) &p );
		if ( p == NULL ) { n_posix_debug_literal( " n_com_class() " ); return -1; }


		SetTimer( hwnd, 1, interval, NULL );

	break;


	case WM_KEYDOWN :

		n = 0;

		if ( wparam == '1' )
		{
			ITaskbarList3_SetProgressState( p, hwnd, TBPF_NOPROGRESS );
		} else
		if ( wparam == '2' )
		{
			ITaskbarList3_SetProgressState( p, hwnd, TBPF_INDETERMINATE );
		} else
		if ( wparam == '3' )
		{
			ITaskbarList3_SetProgressState( p, hwnd, TBPF_NORMAL );
		} else
		if ( wparam == '4' )
		{
			ITaskbarList3_SetProgressState( p, hwnd, TBPF_ERROR );
		} else
		if ( wparam == '5' )
		{
			ITaskbarList3_SetProgressState( p, hwnd, TBPF_PAUSED );
		} else
		if ( wparam == '6' )
		{
			ITaskbarList3_SetProgressValue( p, hwnd, 0, 0 );
			ITaskbarList3_Release( p );
			p = NULL;
		}

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 1 )
		{

			n++;
			if ( n > max_count )
			{
				n = 0;
			}

			// [!] : max value : smoother when high value

			if ( p != NULL ) { ITaskbarList3_SetProgressValue( p, hwnd, n, max_count ); }

		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_timer_exit( hwnd, 0 );

		//n_com_release( p );
		if ( p != NULL ) { ITaskbarList3_Release( p ); }

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}
*/

