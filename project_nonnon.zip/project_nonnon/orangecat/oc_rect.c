// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {

	double x,y,sx,sy;

} n_oc_rect;




#define n_oc_rect_reset( p ) n_oc_rect_set( p, -3,-3,-3,-3 )

void
n_oc_rect_set( n_oc_rect *p, double x, double y, double sx, double sy )
{

	p->x  = x;
	p->y  = y;
	p->sx = sx;
	p->sy = sy;


	return;
}

bool
n_oc_rect_is_hovered( n_oc_rect *p, HWND hwnd )
{
	return n_win_is_hovered_offset( hwnd, p->x, p->y, p->sx, p->sy );
}

